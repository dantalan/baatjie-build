# CHANGELOG · baatjie-build

All changes follow BAATJIE BUILD PROTOCOL.
Format: [TYPE] Description — date

---

## v1.0.0 — 2026-06-23

[MAJOR] Initial release — BAATJIE BUILD Command Center

- Protocol-enforced deployment dashboard for the bluebaatjie Sovereign Ecosystem
- Five-gate build protocol: Drive → GitHub → Netlify → Schema → Env Vars
- AI-powered build brief via Anthropic API (claude-sonnet-4-6)
- Repo selector: Sigsche3ONE, tanOS, talunation-, danOS, taluna
- Build type selector: PATCH / MINOR / MAJOR
- CHANGELOG entry required field — enforced before protocol runs
- Angel number clock detection (08:17 gold)
- Session build + deploy counters
- On-brand: Cinzel / Cormorant Garamond / Space Mono · substrate #030A0E
- Covenant: s'dla sonke, s'fa sonke · 86417

---

_bluebaatjie sovereign · ONE. ◆_
