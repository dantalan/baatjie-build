# baatjie-build · Command Center

> Sovereign deployment infrastructure for the bluebaatjie Ecosystem.

---

## What it is

A protocol-enforced build command center. Every ecosystem product — tanOS, sigscheONE, taluna, dantanOS — deploys through this process. No exceptions.

## The Protocol

```
DECLARE → AI BRIEF → DRIVE ✓ → GITHUB ✓ → NETLIFY ✓ → SCHEMA ✓ → ENV ✓ → LIVE
```

### Five Gates

| Gate | Rule |
|------|------|
| ① DRIVE | File confirmed in Drive root before push |
| ② GITHUB | Pushed to main via Gemini Workspace bridge |
| ③ NETLIFY | Auto-deploy triggered, build log confirmed |
| ④ SCHEMA | DB changes in `/supabase/migrations`, RLS on every table |
| ⑤ ENV VARS | Set in BOTH `.env.local` AND Netlify dashboard — they do not auto-sync |

Gates ④ and ⑤ can be skipped if no DB or config changes were made.

### Build Types

| Type | When |
|------|------|
| PATCH | Bug fix, no new features |
| MINOR | New feature, nothing broken |
| MAJOR | Breaking change, full rebuild |

### Rules

- CHANGELOG.md entry required before every run
- Schema committed to `/supabase/migrations`
- Append-only tables block UPDATE/DELETE
- Branch → preview → merge discipline for non-trivial changes
- Env vars: never assume they auto-sync — set explicitly in both places

## Stack

- Single `index.html` — no build step required
- Anthropic API: `claude-sonnet-4-6` for AI build briefs
- Deployed via Netlify · auto-build on push to `main`

## Deploy target

`baatjie-build.netlify.app`

---

## Covenant

> s'dla sonke, s'fa sonke

**bluebaatjie sovereign · ONE. ◆ · 86417**
